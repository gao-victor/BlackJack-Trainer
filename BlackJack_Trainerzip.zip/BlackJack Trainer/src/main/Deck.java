package main;

import java.util.ArrayList;
import java.util.Collections;

public class Deck {
	
	int count;
	ArrayList<Card> deck = new ArrayList<Card>();
	String[] suites = new String[]{"Clubs", "Spades", "Diamonds", "Hearts"};
	String[] faceCards = new String[] {"Jack","Queen","King","Ace"};
	public Deck() {
		count = 52;
		for(int i = 0;i<4; i++) {
			for(int j=2; j<=10; j++) {
				
				deck.add(new Card (suites[i],Integer.toString(j)));
			}
		}
		for(int i = 0;i<4; i++) {
			for(int j=0; j<4; j++) {
				deck.add(new Card(suites[i],faceCards[j]));
			}
		}
		shuffle();
	}
	
	public void shuffle() {
		Collections.shuffle(deck);
	}
	
	public String toString() {
		String output = "";
		for (int i =0; i < deck.size();i++) {
			output += deck.get(i) + "\n";
		}
		output += "---------------------------- \n";
		return output;
	}
	
	
}
