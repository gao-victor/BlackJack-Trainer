package main;

public class Card {
	/**
	 * Author @Victor Gao
	 * 6/16/2022
	 * 
	 */
	
	String suite;
	String number;
	int value;
	int runningCount;
	
	public Card(String suite, String number) {
		this.suite = suite;
		this.number = number;
		if (this.number.equals("Jack")) {
			value = 10;
		}
		else if (this.number.equals("Queen")) {
			value = 10;
		}
		else if (this.number.equals("King")) {
			value = 10;
		}
		else if (this.number.equals("Ace")) {
			value = 11;
		}
		else value = Integer.parseInt(number);
		
		//Hi-Lo Card counting system
		if (value >=10) {
			runningCount = -1;
		}
		else if (value >= 7) {
			runningCount = 0;
		}
		else {
			runningCount = 1;
		}
	}

	public String getSuite() {
		return suite;
	}

	public String getNumber() {
		return number;
	}
	
	public String toString() {
		return number + " of " + suite;
	}

}
