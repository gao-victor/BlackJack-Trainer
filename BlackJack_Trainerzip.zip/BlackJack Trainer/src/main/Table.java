package main;

import java.util.ArrayList;
import java.util.Collections; 

public class Table {
	
	ArrayList<Player> losers = new ArrayList<Player>();
	int numberOfDecks;
	ArrayList<Card> deck = new ArrayList<Card>();
	ArrayList<Player> activePlayers = new ArrayList<Player>();
	Dealer dealer = new Dealer();
	public Table(int numberOfDecks, int players) {

		if (players > 7 || players < 1) {
			throw new ArrayIndexOutOfBoundsException("Too many players; table is full at 7");
		}
		for (int i = 0; i <players; i++) {
			activePlayers.add(new Player(500));
		}
		if(numberOfDecks <4) {
			throw new ArithmeticException("number of decks has to be at least 4");
		}
		this.numberOfDecks = numberOfDecks;
		for(int i =0; i< numberOfDecks; i++) {
			Deck d = new Deck();
			deck.addAll(d.deck);
		}
		Collections.shuffle(deck);
	}
	
	public void shuffle() {
		deck.clear();
		for(int i= 0; i < numberOfDecks; i++) {
			deck.addAll(new Deck().deck);
		}
		Collections.shuffle(deck);
		System.out.println("Deck was shuffled");
	}
	
	public void changeNumberOfDecks(int newCount) {
		if (newCount <= 0) {
			System.err.println("number of decks has to be at least 1");
		}
		else {
			deck.clear();
			for(int i= 0; i < newCount; i++) {
				deck.addAll(new Deck().deck);
			}
			Collections.shuffle(deck);
			numberOfDecks = newCount;
		}
	}
	
	public boolean addPlayer(Player p) {
		if (activePlayers.size() >= 7) {
			System.err.println("Table has reached capacity; Maximum 7 Players");
			return false;
		}
		else{
			activePlayers.add(p);
			return true;
		}
	}
	
	public void clearTable() {
		//check for who won/tied/lost
		int PN = 1;
			for(int i =0; i<activePlayers.size();i++) {
				if (activePlayers.get(i).hand.size() == 2 && activePlayers.get(i).Score.get(activePlayers.get(i).highestLegalScore) == 21) {
					if (activePlayers.get(i).splitPlayer) {
						activePlayers.get(i-1).chips += Math.round(2.5*activePlayers.get(i).bet);
						System.out.println("P" + (PN) + ": You hit BlackJack! You win " + Math.round(1.5 * activePlayers.get(i).bet) + " chips");
						activePlayers.get(i).bet = 0;
					}
					else{
						activePlayers.get(i).chips += Math.round(2.5 * activePlayers.get(i).bet);
						System.out.println("P" + (PN) + ": You hit BlackJack! You win " + Math.round(1.5 * activePlayers.get(i).bet) + " chips");
						activePlayers.get(i).bet = 0;
						
					}
					
				}
				else if (activePlayers.get(i).busted) {
					if (activePlayers.get(i).splitPlayer) {
						int bet = activePlayers.get(i).bet;
						System.out.println("P" + (PN) + ": You busted; You lost " + bet + " chips");
					}
					else{
						int bet = activePlayers.get(i).bet;
						System.out.println("P" + (PN) + ": You busted; You lost " + bet + " chips");
						activePlayers.get(i).bet = 0;
					}
				}
				else if (dealer.busted) {
					if (activePlayers.get(i).splitPlayer) {
						activePlayers.get(i-1).chips += 2 * activePlayers.get(i).bet;
						System.out.println("P" + (PN) + ": Dealer busted; You win " + activePlayers.get(i).bet + " chips");
						activePlayers.get(i).bet = 0;
					}
					else{
						activePlayers.get(i).chips += 2* activePlayers.get(i).bet;
						System.out.println("P" + (PN) + ": Dealer busted; You win " + activePlayers.get(i).bet + " chips");
						activePlayers.get(i).bet = 0;
					}
				}
				else if (activePlayers.get(i).Score.get(activePlayers.get(i).highestLegalScore) < dealer.Score.get(dealer.highestLegalScore)) {
					if(activePlayers.get(i).splitPlayer){
						int bet = activePlayers.get(i).bet;
						System.out.println("P" + (PN) + ": You lost " + bet + " chips");
						activePlayers.get(i).bet = 0;
					}
					else{
						int bet = activePlayers.get(i).bet;
						System.out.println("P" + (i+1) + ": You lost " + bet + " chips");
						activePlayers.get(i).bet = 0;
					}
				}
				else if (activePlayers.get(i).Score.get(activePlayers.get(i).highestLegalScore) == dealer.Score.get(dealer.highestLegalScore)) {
					if (activePlayers.get(i).splitPlayer) {
						activePlayers.get(i-1).chips += activePlayers.get(i).bet;
						System.out.println("P" + (PN) + ": You split");
						activePlayers.get(i).bet = 0;
					}
					else {
						activePlayers.get(i).chips += activePlayers.get(i).bet;
						System.out.println("P" + (PN) + ": You split");
						activePlayers.get(i).bet = 0;
					}	
				}
				else {
					if (activePlayers.get(i).splitPlayer) {
						activePlayers.get(i-1).chips += 2* activePlayers.get(i).bet;
						System.out.println("P" + (PN) + ": You win " + activePlayers.get(i).bet + " chips");
						activePlayers.get(i).bet = 0;
					}
					else{
						activePlayers.get(i).chips += 2* activePlayers.get(i).bet;
						System.out.println("P" + (PN) + ": You win " + activePlayers.get(i).bet + " chips");
						activePlayers.get(i).bet = 0;
					}
					
				}
				if (i == activePlayers.size()-1) {
					continue;
				}
				else {
					if (activePlayers.get(i+1).splitPlayer) {
						continue;
					}
					else {
						PN++;
					}
				}
				activePlayers.get(i).hand.clear();
				activePlayers.get(i).Score.clear();
				activePlayers.get(i).busted = false;
				activePlayers.get(i).indexOfLastAce = -1;
			}
			dealer.hand.clear();
			dealer.hiddenCard = null;
			dealer.Score.clear();;
			dealer.busted = false;
			dealer.indexOfLastAce = -1;
			System.out.print("\n");
			
			//remove splitHand players
			for(int i =0; i<activePlayers.size(); i++) {
				if (activePlayers.get(i).splitPlayer) {
					activePlayers.remove(i);
				}
			}
			
			//prints out each person's chip count
			for(int i =0; i < activePlayers.size(); i++) {
				if (activePlayers.get(i).chips == 0) {
					continue;
				}
				System.out.println("P" + (i+1) + ": " + activePlayers.get(i).toString(activePlayers.get(i).chips));
			}
			System.out.println(" ");
			//removes losers
			int helper = 0;
			int count = 0;
			while ((helper) < activePlayers.size()) {
				if (activePlayers.get(helper).chips < 1) {
					activePlayers.remove(helper);
					System.out.println("P" + (count +1) + ": You are out of chips");
				}
				else {
					helper++;
				}
				count++;
			}
		}
	
	
	public Card deal() {
		if (deck.size() <= 0) {
			System.err.println("Deck is empty");
			return null;
		}
		Card s = deck.get(deck.size()-1);
		deck.remove(deck.size()-1);
		return s;
	}
	
	
	public String toString() {
		String output = "";
		for(int i =0; i<activePlayers.size(); i++) {
			output += "P" + (i+1) + activePlayers.get(i).toString(activePlayers.get(i).hand) + "\n";
		}
		return output;
	}
	
}
