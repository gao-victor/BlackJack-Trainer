package main;

import java.util.ArrayList;

public class Dealer extends Player {
	/**
	 * @author Victor Gao
	 * 6/16/2022
	 */
	
	Card hiddenCard;

	public Dealer() {
		//Dealer has 0 chips and is always playing
		super(0);
		playing = true;
	}
	
	public void deal(Card a) {
		if (!busted) {
			if (hiddenCard == null) {
				hiddenCard = a;
			}
			else if (hand.size() == 0) {
				Score.add(a.value);
				hand.add(a);
			}
			else{
				if (Score.size() > 1) {
					for(int i =0; i<Score.size(); i++) {
						Score.set(i, Score.get(i)+a.value);
					}
				}
				else{
					Score.set(0, Score.get(0)+a.value);
				}
				hand.add(a);
			}
			if (hand.size() > 0) {
				for (int i = hand.size()-1;i<hand.size();i++) {
					if (hand.get(i).number.equals("Ace")) {
						Score.add(Score.get(Score.size()-1)-10);
					}
				}
			}

			for(int i =0; i <Score.size(); i++) {
				if (Score.get(i) >21) {
					busted = true;
				}
				else {
					busted = false;
					highestLegalScore = i;
					break;
				}
			}
			if (highestLegalScore != 0) {
				ArrayList<Integer> copy = new ArrayList<Integer>();
				for(int i =highestLegalScore; i<Score.size();i++) {
					copy.add(Score.get(i));
				}
				Score = copy;
			}
		}
		if (busted) {
			System.out.println("You Busted");
		}
		highestLegalScore = 0;
	}
	
	public void bet() {
		return;
	}
	
	public String toString() {
		String output = "hand is:\n";
		for (int i = 0; i<hand.size();i++) {
			output += hand.get(i) + ", ";
		}
		String scores = Score.get(0) + "";
		for(int i =1; i<Score.size();i++) {
			scores += "/" + Score.get(i);
		}
		return output + "\n" + "Dealer's at: " + scores + "\n";
	}

}
