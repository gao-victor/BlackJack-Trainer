package main;

import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class Main {
	
	public static void main(String[] args) {
		// Code that takes live input from users
		Scanner keys = new Scanner(System.in);
		boolean active = true;
		boolean gameReady = false;
		Table game = null;
		int runningCount = 0;
		double trueCount = 0;
		while (!gameReady) {
			System.out.println("Do you want to Play? Enter 'QUIT' to exit; Otherwise type anything to continue");
			String line = keys.nextLine();
			if (line.equals("q")){
				active = false;
				break;
			}
			System.out.println("How many Decks? (4+)");
			try {
	        	int decks = Integer.parseInt(keys.nextLine());
	        	System.out.println("How many Players? (1-7)");
	        	int players = Integer.parseInt(keys.nextLine());
	        	game = new Table(decks, players);
	        	gameReady = true;
			}
	        catch (Exception e) {
	        	System.err.println("Invalid Number; try again");
	        }
		}
		while (active) {
			//betting stage
			for(int i =0; i < game.activePlayers.size(); i++) {
				int bet;
				boolean helper = true;
				System.out.println("How much do you want to bet P" + (i + 1) + "?");
				System.out.println("You have " + game.activePlayers.get(i).chips + " chips");
				//ask them how much they want to bet and if they have enough
				while (helper) {
					try {
						bet = Integer.parseInt(keys.nextLine());
						if (bet < 0 || bet > game.activePlayers.get(i).chips) {
							System.err.println("Invalid Bet Amount");
						}
						else {
							game.activePlayers.get(i).bet(bet);
							System.out.println("You have " + game.activePlayers.get(i).chips + " chips left \n");
							helper = false;
						}
					}
					catch(Exception e){
						System.err.println("Must be an integer");
					}
				}
			}
			System.out.println("");
			//card dealing stage
			System.out.println("Cards will be dealt out now: \n");
			for (int i=0; i<game.activePlayers.size(); i++) {
				Card s = game.deal();
				game.activePlayers.get(i).deal(s);
				System.out.println(s);
				runningCount += s.runningCount;
				trueCount = ((double)runningCount)/(Math.round((game.deck.size()/52.0)*100/100));
				System.out.println("runningCount is:" + runningCount);
				System.out.println("trueCount is:" + trueCount);
			}
			Card s = game.deal();
			game.dealer.deal(s);
			for (int i=0; i<game.activePlayers.size(); i++) {
				s = game.deal();
				game.activePlayers.get(i).deal(s);
				System.out.println(s);
				runningCount += s.runningCount;
				trueCount = ((double)runningCount)/(Math.round((game.deck.size()/52.0)*100/100));
				System.out.println("runningCount is:" + runningCount);
				System.out.println("trueCount is:" + trueCount);
			}
			s = game.deal();
			game.dealer.deal(s);
			System.out.println(s);
			runningCount += s.runningCount;
			trueCount = ((double)runningCount)/(Math.round((game.deck.size()/52.0)*100/100));
			System.out.println("runningCount is:" + runningCount);
			System.out.println("trueCount is:" + trueCount);
			System.out.println("\n Dealer " + game.dealer.toString());
			System.out.println(game);
			
			//iterate through every player and have them keep hitting until they hit the highest combo/bust
				//helper integer variable to see if everyone busted; if everyone busted dealer wins by default
			int bustees = 0;
			int PN = 1;
			for (int i =0; i< game.activePlayers.size();i++) {
				boolean keepPlaying = true;
				
				//helper variables for split and double down; at the end of the first iteration both will become true regardless of what happens 
				boolean doubleDown = false;
				boolean split = false;
				
				if (game.activePlayers.get(i).splitPlayer) {
					split = true;
				}
				while (keepPlaying){
					if (game.activePlayers.get(i).hand.size() == 2 && game.activePlayers.get(i).Score.get(0) == 21) {
						System.out.println("P" + (PN) + " hit BlackJack! \n");
						keepPlaying = false;
						continue;
					}
					if (game.activePlayers.get(i).busted) {
						keepPlaying = false;
						continue;
					}
					System.out.println("Do you want to stay, double down, split or hit P" + (PN) + "? Type 'h' to hit, 'd' to double down, 'sp' to split or 'st' to stay \n");
					
					System.out.println("P" + PN + game.activePlayers.get(i).toString(game.activePlayers.get(i).hand));
					System.out.println("P" + PN + game.activePlayers.get(i).toString(game.activePlayers.get(i).chips));
					System.out.println("\n Dealer " + game.dealer.toString());
					System.out.println("\nrunningCount is:" + runningCount);
					System.out.println("trueCount is:" + trueCount + "\n");
					
					
					
					String line = keys.nextLine();
					System.out.println("");
					if (line.equals("st")){
						//for staying
						keepPlaying = false;
					}
					else if (line.equals("d")) {
						if (doubleDown){
							System.out.println("Cannot double down anymore");
						}
						else if (game.activePlayers.get(i).bet *2 > game.activePlayers.get(i).chips + game.activePlayers.get(i).bet) {
							System.out.println("Insufficient funds to double down");
						}
						else {
							game.activePlayers.get(i).chips -= game.activePlayers.get(i).bet;
							game.activePlayers.get(i).bet = 2*game.activePlayers.get(i).bet;
							System.out.println("Succesfully doubled donwn");
						}
					}
					else if (line.equals("sp")) {
						// for splitting
						if (split) {
							System.out.println("Cannot split anymore");
						}
						else if ((game.activePlayers.get(i).chips + game.activePlayers.get(i).bet) < 2 * game.activePlayers.get(i).bet) {
							System.out.println("Cannot split; insufficient funds");
							
						}
						else if (game.activePlayers.get(i).hand.get(0).number.equals(game.activePlayers.get(i).hand.get(1).number)) {
							
							//create duplicate player with the second card
							game.activePlayers.get(i).chips -= game.activePlayers.get(i).bet;
							Player splitHand = new Player(game.activePlayers.get(i).chips);
							splitHand.bet = game.activePlayers.get(i).bet;
							game.activePlayers.add(i+1, splitHand);
							s = game.activePlayers.get(i).hand.get(1);
							game.activePlayers.get(i).hand.remove(1);
							splitHand.deal(s);
							splitHand.splitPlayer = true;
							//if you're splitting a pair of Aces
							if (s.number.equals("Ace")) {
								game.activePlayers.get(i).Score.set(0, 11);
								game.activePlayers.get(i).Score.set(1, 1);
								game.activePlayers.get(i).indexOfLastAce = 0;
							}
							
							else {
								game.activePlayers.get(i).Score.set(0, game.activePlayers.get(i).Score.get(0)/2);
							}
							split = true;
							System.out.println("Succesfully split");
							continue;
						}
						else {
							System.out.println("Not a pair");
						}
					}
					else if (line.equals("h")) {
						// for hitting
						s = game.deal();
						System.out.println(s + "\n");
						runningCount += s.runningCount;
						trueCount = ((double)runningCount)/(Math.round((game.deck.size()/52.0)*100/100));
						System.out.println("runningCount is:" + runningCount);
						System.out.println("trueCount is:" + trueCount);
						game.activePlayers.get(i).deal(s);
						if (game.activePlayers.get(i).busted)
						{
							bustees++;
						}
						else {
							System.out.println("P" + (PN) + ": " + game.activePlayers.get(i).toString(game.activePlayers.get(i).hand));
						}
						doubleDown = true;
						split = true;
					}
				}
				if (!game.activePlayers.get(i).splitPlayer) {
					if (i == game.activePlayers.size()-1) {
						continue;
					}
					else {
						if (game.activePlayers.get(i+1).splitPlayer) {
							continue;
						}
						else {
							PN++;
						}
					}
				}
			}
			
			//if everyone busted, then clear the table; otherwise dealer gets dealt cards
			if (bustees == game.activePlayers.size()) {
				game.clearTable();
			}
			
			//dealer gets dealt the cards assuming there's at least one player who didn't bust
			else{
				s = game.dealer.hiddenCard;
				System.out.println("\nHidden Card is: " + s + "\n");
				game.dealer.deal(s);
				runningCount += s.runningCount;
				trueCount = ((double)runningCount)/(Math.round((game.deck.size()/52.0)*100/100));
				System.out.println("runningCount is:" + runningCount);
				System.out.println("trueCount is:" + trueCount);
				
				System.out.println("Dealer" + game.dealer.toString(game.dealer.hand));
				while (game.dealer.Score.get(0) < 17 && !game.dealer.busted) {
					s = game.deal();
					System.out.println("Card is: " + s);
					game.dealer.deal(s);
					runningCount += s.runningCount;
					trueCount = ((double)runningCount)/(Math.round((game.deck.size()/52.0)*100/100));
					System.out.println("runningCount is:" + runningCount);
					System.out.println("trueCount is:" + trueCount);
					System.out.println("Dealer is at " + game.dealer.Score.get(0));
				}
				System.out.println(" ");
				game.clearTable();
			}
			
			//if there's less than half the deck left, shuffle
			if (game.deck.size() <= (game.numberOfDecks * 52)/2) {
				game.shuffle();
				runningCount = 0;
				trueCount = 0;
			}
			//clear the table
			System.out.println("\n Type 'q' to exit, 'p' to play again, 'a' to add players (table is full at 7 players) \n"
					+ "'s' to shuffle the deck, 'c' to show how many cards left or 'd' to change the number of decks");
			boolean helper = true;
			while (helper) {
				String line = keys.nextLine();
				if (line.equals("q")) {
					active = false;
					helper = false;
				}
				else if (line.equals("a")) {
					System.out.println("How many players");
					line = keys.nextLine();
					try {
						int number = Integer.parseInt(line);
						for (int i =0; i<number; i++) {
								if (game.addPlayer(new Player(500))) {
									System.out.println("Succesfully added " + (i+1) + " player(s)");
								}
								else {
									break;
								}
								
						}
					}
					catch (Exception e) {
						System.err.println("Not a proper number");
					}
				}
				else if (line.equals("d")){
					System.out.println("How many decks?");
					try {
						int number = Integer.parseInt(line);
						game.changeNumberOfDecks(number);
						runningCount = 0;
						trueCount = 0;
						System.out.println("Deck now has " + number + " decks");
					}
					catch (Exception e) {
						System.err.println("Not a proper number");
					}
				}
				else if (line.equals("p")) {
					if (game.activePlayers.size() <=0) {
						System.err.println("No players at table; please add a player first");
					}
					else{
						helper = false;
					}
				}
				else if (line.equals("s")) {
					game.shuffle();
					runningCount = 0;
					trueCount = 0;
				}
				else if (line.equals("c")){
					System.out.println("Deck of " + game.numberOfDecks + " has " + game.deck.size() + " cards left");
				}
			}
		}
		
	}
}
