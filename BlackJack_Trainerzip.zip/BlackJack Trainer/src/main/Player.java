package main;

import java.util.ArrayList;
/**
 * 
 * @author Victor Gao
 *6/16/2022
 */

public class Player {
	ArrayList<Card> hand = new ArrayList<Card>();
	int chips;
	boolean busted;
	ArrayList<Integer> Score = new ArrayList<Integer>();
	int bet;
	int indexOfLastAce =-1;
	int highestLegalScore = 0;
	boolean splitPlayer;
	boolean playing;
	
	public Player(int chips) {
		hand.clear();
		this.chips = chips;
		busted = false;
		bet = 0;
		splitPlayer = false;
		playing = false;
	}
	
	public void deal(Card a) {
		if (!busted) {
			if (hand.size() == 0) {
				Score.add(a.value);
			}
			else{
				if (Score.size() > 1) {
					for(int i =0; i<Score.size(); i++) {
						Score.set(i, Score.get(i)+a.value);
					}
				}
				else{
					Score.set(0, Score.get(0)+a.value);
				}
			}
			hand.add(a);
			for(int i = hand.size()-1; i<hand.size();i++) {
				if (hand.get(i).number.equals("Ace")) {
					Score.add(Score.get(Score.size()-1)-10);
					indexOfLastAce = i;
			}
			}
			
			//check for if the player busted after being dealt a card
			for(int i =0; i <Score.size(); i++) {
				if (Score.get(i) >21) {
					busted = true;
				}
				else {
					busted = false;
					highestLegalScore = i;
					break;
				}
			}
			if (highestLegalScore != 0) {
				ArrayList<Integer> copy = new ArrayList<Integer>();
				for(int i =highestLegalScore; i<Score.size();i++) {
					copy.add(Score.get(i));
				}
				Score = copy;
			}
		}
		if (busted) {
			System.out.println("You Busted \n");
		}
		highestLegalScore = 0;
	}
	
	public void bet(int bet) {
		if (bet > chips) {
			System.err.println("Not enough chips");
		}
		else {
			chips -= bet;
			this.bet += bet;
		}
	}
	
	public String toString(ArrayList<Card> hand) {
		String output = ": hand is:\n";
		for (int i = 0; i<hand.size();i++) {
			output += hand.get(i) + ", ";
		}
		String scores = Score.get(0) + "";
		for(int i =1; i<Score.size();i++) {
			scores +=  "/" + Score.get(i);
		}
		return output + "\n" + "You're at: " + scores + "\n";
	}
		
	public String toString(int chips) {
		return ": You're at " + chips + " chips \n";
	}
	
}
